from setuptools import setup, find_packages
setup(
    name="MetricSpaces",
    version="1.0.0",
    author="Braulio Ramses Hernandez Martinez",
    author_email ="1578615h@umich.mx",
    description="Similitary search in metric spaces ",
    long_description="",
    url="",
    packages = find_packages(),
)
