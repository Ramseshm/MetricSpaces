"""
inicio de modulo 
"""