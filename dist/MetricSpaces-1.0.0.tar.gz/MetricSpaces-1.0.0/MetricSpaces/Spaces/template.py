
dix=[""]
def loadDB(dbloc):
  pass
  #db=open(dbloc).readlines()
  #return len(db)

def add(v):
  #dix[0]=
  pass

def tam():
  return len(dix)
  
def name():
  #return "space name"
  pass

def Distance(i,j):
  pass
  #return distance